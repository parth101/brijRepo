package com.mytech;



public class Employee {
public String uname;
public String pwd;
public Address empAddress;

public Address getEmpAddress() {
	return empAddress;
}
public void setEmpAddress(Address empAddress) {
	this.empAddress = empAddress;
}
public String getUname() {
	return uname;
}
public void setUname(String uname) {
	this.uname = uname;
}
public String getPwd() {
	return pwd;
}
public void setPwd(String pwd) {
	this.pwd = pwd;
}

}
