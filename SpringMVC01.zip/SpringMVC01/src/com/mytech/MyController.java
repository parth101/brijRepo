package com.mytech;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;



@Controller
class MyController{
/*class MyController implements Controller{

	  public ModelAndView handleRequest(HttpServletRequest req,
	  HttpServletResponse res) throws Exception { 
		  String  nm=req.getParameter("uname"); 
		  String pwd=req	.getParameter("pwd");
	  System.out.println("Name is:"+nm); 
	  ModelAndView  model=new ModelAndView("success");
	  model.addObject("NM",nm);
	  return model;
	  }*/	 
	/*@ModelAttribute
	public void addCommon(Model model){
		model.addAttribute("header","This is Annotation Based MVC");
	}*/
	
	@RequestMapping(value="/sendForm.htm" )
	public ModelAndView disply(@ModelAttribute("emp") Employee emp,BindingResult result)
			throws Exception {
	if(result.hasErrors()){
		//System.out.println(result.getErrorCount());
		ModelAndView model =new ModelAndView("login");
		return model;
	}
		System.out.println("Name is:" + emp.uname + "\n" + "Password is:" + emp.pwd);
		ModelAndView model = new ModelAndView("success");
		model.addObject("Emp",emp);
		return model;
	}

}
