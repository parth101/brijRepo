package com.bp.pojo;

import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="PTE")
@PrimaryKeyJoinColumn(name="eid")
public class PartTimeEmployee extends CurrentEmployee{

	String ptiming;
	int salary;
	
	public PartTimeEmployee() {
		// TODO Auto-generated constructor stub
	}
	public String getPtiming() {
		return ptiming;
	}
	public void setPtiming(String ptiming) {
		this.ptiming = ptiming;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	
	
	@Override
	public String toString() {
		return "PartTimeEmployee [ptiming=" + ptiming + ", salary=" + salary + "]";
	}
	
	
	
	
}
