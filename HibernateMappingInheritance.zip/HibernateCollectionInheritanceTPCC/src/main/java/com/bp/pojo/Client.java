package com.bp.pojo;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;


public class Client {

	public static void main(String args[])
	{
		try
		{
			 //BasicConfigurator.configure();
			System.out.println("Start....");
			SessionFactory sf=AhibernateUtil.getSessionFactory();
			Session session=sf.openSession();
			Transaction tx=session.beginTransaction();
			//Emloyee
			Employee e = new Employee();
			e.setId(101);
			e.setName("Ram");
			
			Set<Integer> s= new HashSet<Integer>();
			s.add(9718);
			e.setPhone(s);
			Integer it = (Integer) session.save(e);
			System.out.println(it.intValue());
			
			//CurrentEmployee
			
			CurrentEmployee ce= new CurrentEmployee();
			ce.setBranch("XSTI");
			ce.setTiming("5.34PM");
			Integer it1 = (Integer) session.save(ce);
			System.out.println(it1.intValue());
			
			//PartTimeEmployee
			
			PartTimeEmployee pte= new PartTimeEmployee();
			pte.setPtiming("6.00PM");
			pte.setSalary(2000);
			Integer it2 = (Integer) session.save(pte);
			System.out.println(it2.intValue());
			
			
			
			tx.commit();
			session.close();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
