package com.bp.pojo;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

import org.hibernate.annotations.CollectionOfElements;

@Entity
@Table(name="employee")
@Inheritance(strategy=InheritanceType.JOINED)
public class Employee {
	
	@Id @GeneratedValue(strategy= GenerationType.AUTO)
	int eid;
	String name;
	@CollectionOfElements
	Set<Integer> phone;

	public Employee() {
		// TODO Auto-generated constructor stub
	}
	
	
	public int getId() {
		return eid;
	}

	public void setId(int id) {
		this.eid = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	public Set<Integer> getPhone() {
		return phone;
	}


	public void setPhone(Set<Integer> phone) {
		this.phone = phone;
	}


	@Override
	public String toString() {
		return "Employee [id=" + eid + ", name=" + name + ", phone=" + phone + "]";
	}

	
	
	
	
	
}
