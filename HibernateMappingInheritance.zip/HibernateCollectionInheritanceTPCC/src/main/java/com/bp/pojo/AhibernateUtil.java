package com.bp.pojo;


import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

public class AhibernateUtil {
	static SessionFactory  factory;
	static
	{
		try
		{
			AnnotationConfiguration cfg=new AnnotationConfiguration();
			cfg=(AnnotationConfiguration) cfg.configure();
			factory=cfg.buildSessionFactory();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public static SessionFactory getSessionFactory()
	{
		return factory;
	}
	
}
