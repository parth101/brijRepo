package com.bp.pojo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;


public class Client {

	public static void main(String args[])
	{
		try
		{
			 //BasicConfigurator.configure();
			System.out.println("Start....");
			SessionFactory sf=AhibernateUtil.getSessionFactory();
			Session session=sf.openSession();
			Transaction tx=session.beginTransaction();

			Employee e = new Employee();
			e.setId(101);
			e.setName("Ram");
			
			
			
			session.save(e);
			tx.commit();
			session.close();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
