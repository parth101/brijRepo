package com.bp.pojo;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue(value="CEMP")
public class CurrentEmployee extends Employee{

	String timing;
	String branch;
	
	
	public CurrentEmployee() {
		// TODO Auto-generated constructor stub
	}
	public String getTiming() {
		return timing;
	}
	public void setTiming(String timing) {
		this.timing = timing;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	
	
	
	@Override
	public String toString() {
		return "CurrentEmployee [timing=" + timing + ", branch=" + branch + "]";
	}
	
	
	
}
