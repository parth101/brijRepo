package com.bp.pojo;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="PTE")
@AttributeOverrides({  
    @AttributeOverride(name="eid", column=@Column(name="eid")),  
    @AttributeOverride(name="name", column=@Column(name="name"))  
})
public class PartTimeEmployee extends Employee{

	String ptiming;
	int salary;
	
	public PartTimeEmployee() {
		// TODO Auto-generated constructor stub
	}
	public String getPtiming() {
		return ptiming;
	}
	public void setPtiming(String ptiming) {
		this.ptiming = ptiming;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	
	
	@Override
	public String toString() {
		return "PartTimeEmployee [ptiming=" + ptiming + ", salary=" + salary + "]";
	}
	
	
	
	
}
