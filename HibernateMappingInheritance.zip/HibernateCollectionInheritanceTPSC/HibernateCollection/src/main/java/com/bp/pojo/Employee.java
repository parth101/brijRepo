package com.bp.pojo;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.CollectionOfElements;

@Entity
public class Employee {
	
	@Id @GeneratedValue(strategy= GenerationType.AUTO)
	int id;
	String name;
	@CollectionOfElements
	Set<Integer> phone;

	public Employee() {
		// TODO Auto-generated constructor stub
	}
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	public Set<Integer> getPhone() {
		return phone;
	}


	public void setPhone(Set<Integer> phone) {
		this.phone = phone;
	}


	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", phone=" + phone + "]";
	}

	
	
	
	
	
}
